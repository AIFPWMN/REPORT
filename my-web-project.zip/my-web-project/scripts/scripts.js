import Vue from "https://cdn.jsdelivr.net/npm/vue@2.7.8/dist/vue.js";

new Vue({
  el: '#app',
  data: {
    message: 'Hello Vue!'
  }
});

document.getElementById('send-button').addEventListener('click', function() {
    var chatInput = document.getElementById('chat-input');
    var chatMessages = document.getElementById('chat-messages');
    
    if (chatInput.value.trim() !== "") {
        var userMessage = document.createElement('div');
        userMessage.textContent = "User: " + chatInput.value;
        userMessage.className = "message user";
        chatMessages.appendChild(userMessage);

        fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer sk-proj-mpbYkdQnb1Oj3MTDPk2IT3BlbkFJqp9A1qUDcsUjjX0w4VFC'  // استبدل YOUR_API_KEY بمفتاح API الفعلي الخاص بك
            },
            body: JSON.stringify({
                "model": "gpt-3.5-turbo",
                "messages": [{"role": "user", "content": chatInput.value}],
                "max_tokens": 150
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                throw new Error(data.error.message);
            }
            var aiMessage = document.createElement('div');
            aiMessage.textContent = "ENG-WASEEM: " + data.choices[0].message.content.trim();
            aiMessage.className = "message bot";
            chatMessages.appendChild(aiMessage);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        })
        .catch(error => {
            console.error('Error:', error); // طباعة الأخطاء في وحدة التحكم
            var errorMessage = document.createElement('div');
            errorMessage.textContent = "ENG-WASEEM: Sorry, there was an error processing your request.";
            errorMessage.className = "message bot";
            chatMessages.appendChild(errorMessage);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        });

        chatInput.value = "";
    }
});

document.getElementById('like-button').addEventListener('click', function() {
    alert('You liked the video.');
});

document.getElementById('dislike-button').addEventListener('click', function() {
    alert('You disliked the video.');
});

document.getElementById('love-button').addEventListener('click', function() {
    alert('You loved the video.');
});

document.addEventListener('keydown', function(event) {
    const key = event.key;
    if (key >= '1' && key <= '9') {
        const iframe = document.querySelector('iframe');
        iframe.src += `#${key}`;
    }
});

// تحويل الصفحة بعد 15 دقيقة
setTimeout(function() {
    window.location.href = 'file:///C:/Users/Toshiba/Desktop/stratWAP/index.html';
}, 15 * 60 * 1000); // 15 دقيقة بالمللي ثانية

// عند تحديث الصفحة أو العودة للموقع، التوجه إلى المقطع الأصلي
window.addEventListener('load', function() {
    const iframe = document.querySelector('iframe');
    iframe.src = "https://stories.storydoc.com/7d71238f7fdd197dead72b1b55c2910a/1e9746ed-4517-468b-ae7f-ba4719ae500f/6678c0b4b6724d26a3157541";
});
